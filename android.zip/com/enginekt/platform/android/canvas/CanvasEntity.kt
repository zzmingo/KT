package com.enginekt.platform.android.canvas

import com.enginekt.Context
import com.enginekt.Entity

/**
 * Created by mingo on 17/8/9.
 */
class CanvasEntity(context: Context) : Entity(context) {

    fun initCanvasEntity() {
        init()
    }

}