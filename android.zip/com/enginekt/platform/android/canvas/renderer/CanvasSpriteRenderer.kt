package com.enginekt.platform.android.canvas.renderer

import android.graphics.Matrix
import com.enginekt.RenderingContext
import com.enginekt.platform.android.BitmapTexture
import com.enginekt.platform.android.canvas.CanvasRenderingContext
import com.enginekt.renderer.SpriteRenderer

/**
 * Created by mingo on 17/8/9.
 */
class CanvasSpriteRenderer : SpriteRenderer() {

    private val _matrix: Matrix = Matrix()
    private val _values = FloatArray(9, { 0.0f })

    override fun updateTransform() {
        val mat = entity.transform.worldMatrix
        _values[0] = mat.a.toFloat()
        _values[1] = mat.b.toFloat()
        _values[3] = mat.c.toFloat()
        _values[4] = mat.d.toFloat()
        _values[6] = mat.tx.toFloat()
        _values[7] = mat.ty.toFloat()
        _matrix.reset()
        _matrix.setValues(_values)
    }

    override fun render(context: RenderingContext) {
        if (texture == null) {
            return
        }
        val bitmapTex = texture as BitmapTexture
        val canvasContext = context as CanvasRenderingContext
        val canvas = canvasContext.canvas
        canvas.matrix = _matrix
        canvas.drawBitmap(
                bitmapTex.bitmap,
                -(anchor.x * bitmapTex.width).toFloat(),
                -(anchor.y * bitmapTex.height).toFloat(), null)
    }
}