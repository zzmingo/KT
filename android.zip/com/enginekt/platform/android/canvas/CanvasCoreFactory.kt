package com.enginekt.platform.android.canvas

import com.enginekt.Component
import com.enginekt.CoreFactory
import com.enginekt.Entity
import com.enginekt.KT
import kotlin.reflect.KClass

/**
 * Created by mingo on 17/8/9.
 */
class CanvasCoreFactory : CoreFactory {

    override fun create(): Entity {
        val entity = CanvasEntity(KT.app)
        KT.app.stage.addEntity(entity)
        entity.initCanvasEntity()
        return entity
    }

    override fun <T : Component> create(clazz: KClass<T>): T {
        TODO("not implemented")
    }
}