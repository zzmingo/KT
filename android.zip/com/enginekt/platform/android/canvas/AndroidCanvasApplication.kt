package com.enginekt.platform.android.canvas

import android.content.Context
import android.view.SurfaceHolder
import com.enginekt.*
import com.enginekt.platform.android.AndroidApplication

/**
 * Created by mingo on 17/8/9.
 */
class AndroidCanvasApplication(
        context: Context,
        background: Int = 0x000000,
        orientation: Orientation = Orientation.PORTRAIT,
        resolution: Double = 1.0
) : AndroidApplication(orientation, resolution), SurfaceHolder.Callback, Runnable {

    override val view: CanvasView = CanvasView(context)

    override val renderingContext = CanvasRenderingContext(view)

    override val coreFactory = CanvasCoreFactory()

    private var surfaceHolder: SurfaceHolder? = null

    override fun useDefaultPointerInput(multiple: Boolean) {
    }

    override fun run() {
        while (surfaceHolder != null) {
            logger.print(time.now)
            step()
        }
    }

    override fun internalRender() {
        try {
            renderingContext.canvas = surfaceHolder!!.lockCanvas()
            super.internalRender()
        } finally {
            surfaceHolder!!.unlockCanvasAndPost(renderingContext.canvas)
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
        surfaceHolder = holder
    }

    override fun surfaceDestroyed(holder: SurfaceHolder?) {
        surfaceHolder = null
    }

    override fun surfaceCreated(holder: SurfaceHolder?) {
        surfaceHolder = holder
        Thread(this).start()
    }
}