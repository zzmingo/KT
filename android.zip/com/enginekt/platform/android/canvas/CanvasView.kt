package com.enginekt.platform.android.canvas

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.view.SurfaceHolder
import com.enginekt.View
import com.enginekt.base.event.Event

/**
 * Created by mingo on 17/8/9.
 */
class CanvasView(val context: Context) : View {

    val contentView = ContentView(context)

    override val width: Int get() = contentView.width
    override val height: Int get() = contentView.height

    override val OnResize = Event<Any>()

    override fun dispose() {
        OnResize.dispose()
    }

    inner class ContentView(context: Context) : android.view.SurfaceView(context) {

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            OnResize.invoke(this@CanvasView)
        }

    }
}