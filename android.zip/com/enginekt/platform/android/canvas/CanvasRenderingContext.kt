package com.enginekt.platform.android.canvas

import android.graphics.Canvas
import com.enginekt.core.RenderingContextBase

/**
 * Created by mingo on 17/8/9.
 */
class CanvasRenderingContext(
        val view: CanvasView,
        val background: Int = 0x000000
) : RenderingContextBase() {

    lateinit var canvas: Canvas

    override fun initialize() {
    }

    override fun clear() {
        canvas.drawColor(background)
    }

    override fun dispose() {
    }

}