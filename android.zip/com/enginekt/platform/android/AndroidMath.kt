package com.enginekt.platform.android

import com.enginekt.MathLibrary

/**
 * Created by mingo on 17/8/9.
 */
class AndroidMath : MathLibrary {

    override val E: Double = Math.E
    override val PI: Double = Math.PI

    override fun abs(value: Number): Number {
        return when (value) {
            is Double -> Math.abs(value.toDouble())
            is Int -> Math.abs(value.toInt())
            is Float -> Math.abs(value.toFloat())
            is Long -> Math.abs(value.toDouble())
            else -> Math.abs(value.toDouble())
        }
    }

    override fun sin(value: Double): Double {
        return Math.sin(value)
    }

    override fun cos(value: Double): Double {
        return Math.cos(value)
    }
}