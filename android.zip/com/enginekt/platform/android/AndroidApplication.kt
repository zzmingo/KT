package com.enginekt.platform.android

import android.content.Context
import com.enginekt.Application
import com.enginekt.core.ApplicationBase

abstract class AndroidApplication(
        val context: Context,
        resolution: Double = 1.0
) : ApplicationBase(resolution) {

    override val platform = Application.Platform.Android

    override val logger: AndroidLogger = AndroidLogger()

    override val math: AndroidMath = AndroidMath()

    override val fs: AndroidFileSystem = AndroidFileSystem(context)

    init {
        addDisposable(logger)
    }

    override fun currentMillis(): Long {
        return System.currentTimeMillis()
    }
}