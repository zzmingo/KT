package com.enginekt.platform.android

import android.graphics.Bitmap
import com.enginekt.Texture

/**
 * Created by mingo on 17/8/9.
 */
class BitmapTexture(override val path: String, val bitmap: Bitmap) : Texture {

    override val id: String = path

    override val width: Int = bitmap.width
    override val height: Int = bitmap.height

    override fun dispose() {
        bitmap.recycle()
    }
}