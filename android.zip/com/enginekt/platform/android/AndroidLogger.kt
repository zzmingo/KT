package com.enginekt.platform.android

import android.util.Log
import com.enginekt.Logger

/**
 * Created by mingo on 17/8/9.
 */
class AndroidLogger : Logger {

    companion object {
        val TAG = AndroidLogger::class.simpleName
    }

    override fun dispose() {
    }

    override fun print(vararg o: Any?) {
        Log.d(TAG, o.toList().joinToString(" "))
    }

    override fun debug(tag: String, vararg o: Any?) {
        Log.d(tag, o.toList().joinToString(" "))
    }

    override fun info(tag: String, vararg o: Any?) {
        Log.i(tag, o.toList().joinToString(" "))
    }

    override fun warn(tag: String, vararg o: Any?) {
        Log.w(tag, o.toList().joinToString(" "))
    }

    override fun error(tag: String, vararg o: Any?) {
        Log.e(tag, o.toList().joinToString(" "))
    }
}