package com.enginekt.platform.android

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.enginekt.Asset
import com.enginekt.base.utils.Callback
import com.enginekt.core.FileSystemBase
import java.io.InputStream
import kotlin.reflect.KClass

/**
 * Created by mingo on 17/8/9.
 */
class AndroidFileSystem(val context: Context, autoRelease: Boolean = false) : FileSystemBase(autoRelease) {

    @Suppress("UNCHECKED_CAST")
    override fun <T : Asset> load(path: String, clazz: KClass<T>, callback: Callback<T>) {
        var inputSteam: InputStream? = null
        try {
            inputSteam = context.openFileInput(path)
            val bitmap = BitmapFactory.decodeStream(inputSteam)
            callback.success(BitmapTexture(path, bitmap) as T)
        } catch (e: Throwable) {
            callback.error(e)
        } finally {
            inputSteam?.close()
        }
    }

}